-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 14, 2021 at 07:55 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `adorf`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_group`
--

CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `auth_group`
--

INSERT INTO `auth_group` (`id`, `name`) VALUES
(1, 'customer');

-- --------------------------------------------------------

--
-- Table structure for table `auth_group_permissions`
--

CREATE TABLE `auth_group_permissions` (
  `id` bigint(20) NOT NULL,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `auth_permission`
--

CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add permission', 2, 'add_permission'),
(6, 'Can change permission', 2, 'change_permission'),
(7, 'Can delete permission', 2, 'delete_permission'),
(8, 'Can view permission', 2, 'view_permission'),
(9, 'Can add group', 3, 'add_group'),
(10, 'Can change group', 3, 'change_group'),
(11, 'Can delete group', 3, 'delete_group'),
(12, 'Can view group', 3, 'view_group'),
(13, 'Can add user', 4, 'add_user'),
(14, 'Can change user', 4, 'change_user'),
(15, 'Can delete user', 4, 'delete_user'),
(16, 'Can view user', 4, 'view_user'),
(17, 'Can add content type', 5, 'add_contenttype'),
(18, 'Can change content type', 5, 'change_contenttype'),
(19, 'Can delete content type', 5, 'delete_contenttype'),
(20, 'Can view content type', 5, 'view_contenttype'),
(21, 'Can add session', 6, 'add_session'),
(22, 'Can change session', 6, 'change_session'),
(23, 'Can delete session', 6, 'delete_session'),
(24, 'Can view session', 6, 'view_session'),
(25, 'Can add customer', 7, 'add_customer'),
(26, 'Can change customer', 7, 'change_customer'),
(27, 'Can delete customer', 7, 'delete_customer'),
(28, 'Can view customer', 7, 'view_customer'),
(29, 'Can add order', 8, 'add_order'),
(30, 'Can change order', 8, 'change_order'),
(31, 'Can delete order', 8, 'delete_order'),
(32, 'Can view order', 8, 'view_order'),
(33, 'Can add product', 9, 'add_product'),
(34, 'Can change product', 9, 'change_product'),
(35, 'Can delete product', 9, 'delete_product'),
(36, 'Can view product', 9, 'view_product'),
(37, 'Can add shipping address', 10, 'add_shippingaddress'),
(38, 'Can change shipping address', 10, 'change_shippingaddress'),
(39, 'Can delete shipping address', 10, 'delete_shippingaddress'),
(40, 'Can view shipping address', 10, 'view_shippingaddress'),
(41, 'Can add order item', 11, 'add_orderitem'),
(42, 'Can change order item', 11, 'change_orderitem'),
(43, 'Can delete order item', 11, 'delete_orderitem'),
(44, 'Can view order item', 11, 'view_orderitem'),
(45, 'Can add productmen', 12, 'add_productmen'),
(46, 'Can change productmen', 12, 'change_productmen'),
(47, 'Can delete productmen', 12, 'delete_productmen'),
(48, 'Can view productmen', 12, 'view_productmen'),
(49, 'Can add productwomen', 13, 'add_productwomen'),
(50, 'Can change productwomen', 13, 'change_productwomen'),
(51, 'Can delete productwomen', 13, 'delete_productwomen'),
(52, 'Can view productwomen', 13, 'view_productwomen'),
(53, 'Can add payment', 14, 'add_payment'),
(54, 'Can change payment', 14, 'change_payment'),
(55, 'Can delete payment', 14, 'delete_payment'),
(56, 'Can view payment', 14, 'view_payment'),
(57, 'Can add access attempt', 15, 'add_accessattempt'),
(58, 'Can change access attempt', 15, 'change_accessattempt'),
(59, 'Can delete access attempt', 15, 'delete_accessattempt'),
(60, 'Can view access attempt', 15, 'view_accessattempt'),
(61, 'Can add access attempt', 16, 'add_accessattempt'),
(62, 'Can change access attempt', 16, 'change_accessattempt'),
(63, 'Can delete access attempt', 16, 'delete_accessattempt'),
(64, 'Can view access attempt', 16, 'view_accessattempt'),
(65, 'Can add access log', 17, 'add_accesslog'),
(66, 'Can change access log', 17, 'change_accesslog'),
(67, 'Can delete access log', 17, 'delete_accesslog'),
(68, 'Can view access log', 17, 'view_accesslog');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user`
--

CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `auth_user`
--

INSERT INTO `auth_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`) VALUES
(1, 'pbkdf2_sha256$260000$rdMP1VD4SDVhrGH3leiMN9$7NvwyWumhLvBUPlpgt4K26dILM1UZ/aKJcJZ1OoTT4Y=', '2021-09-10 11:49:32.939861', 1, 'adorf', '', '', 'adorf@gmail.com', 1, 1, '2021-08-23 07:45:49.552206'),
(7, 'pbkdf2_sha256$260000$5pANQTEw4HpxLQNVFefDcC$7STkB8nuyh1P4EfC/ySsnOOsTeuVyjSz8NjH/wfnDPM=', '2021-09-12 06:31:16.727518', 0, 'test', '', '', 'test@test.com', 0, 1, '2021-09-02 14:48:02.008239'),
(10, 'pbkdf2_sha256$260000$9bU25DOfARzoMhfOdopJZH$+N0GGa36lDBeA8H4T4ktp6qoV4SYMffE75VQV6JxK9I=', '2021-09-10 11:36:12.407123', 0, 'mahan', '', '', 'mahansunuwar33@gmail.com', 0, 1, '2021-09-04 14:35:06.951931'),
(11, 'pbkdf2_sha256$260000$lZQ2MOiQKuM7SukYSHgi3v$rXhQwMIExFEe1RWIWYxkQ/fpTSnQolTNEXbIRFbT11k=', '2021-09-06 05:33:36.456814', 0, 'sushant', '', '', 'susanwagle123@gmail.com', 0, 1, '2021-09-06 05:32:19.765336');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_groups`
--

CREATE TABLE `auth_user_groups` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `auth_user_groups`
--

INSERT INTO `auth_user_groups` (`id`, `user_id`, `group_id`) VALUES
(1, 7, 1),
(4, 10, 1),
(5, 11, 1);

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_user_permissions`
--

CREATE TABLE `auth_user_user_permissions` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `axes_accessattempt`
--

CREATE TABLE `axes_accessattempt` (
  `id` int(11) NOT NULL,
  `user_agent` varchar(255) NOT NULL,
  `ip_address` char(39) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `http_accept` varchar(1025) NOT NULL,
  `path_info` varchar(255) NOT NULL,
  `attempt_time` datetime(6) NOT NULL,
  `get_data` longtext NOT NULL,
  `post_data` longtext NOT NULL,
  `failures_since_start` int(10) UNSIGNED NOT NULL CHECK (`failures_since_start` >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `axes_accesslog`
--

CREATE TABLE `axes_accesslog` (
  `id` int(11) NOT NULL,
  `user_agent` varchar(255) NOT NULL,
  `ip_address` char(39) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `http_accept` varchar(1025) NOT NULL,
  `path_info` varchar(255) NOT NULL,
  `attempt_time` datetime(6) NOT NULL,
  `logout_time` datetime(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `axes_accesslog`
--

INSERT INTO `axes_accesslog` (`id`, `user_agent`, `ip_address`, `username`, `http_accept`, `path_info`, `attempt_time`, `logout_time`) VALUES
(1, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36', '127.0.0.1', 'adorf', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', '/admin/login/', '2021-09-09 07:57:47.790042', '2021-09-09 07:58:07.338923'),
(2, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36', '127.0.0.1', 'adorf', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', '/admin/login/', '2021-09-09 09:29:51.357209', '2021-09-09 09:30:21.670670'),
(3, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36', '127.0.0.1', 'test', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', '/account/', '2021-09-09 09:45:38.953824', '2021-09-09 10:21:25.334586'),
(4, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36', '127.0.0.1', 'test', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', '/account/', '2021-09-09 09:48:41.076262', '2021-09-09 10:21:25.334586'),
(5, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36', '127.0.0.1', 'test', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', '/account/', '2021-09-09 09:51:12.356430', '2021-09-09 10:21:25.334586'),
(6, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36', '127.0.0.1', 'test', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', '/account/', '2021-09-09 09:53:24.561692', '2021-09-09 10:21:25.334586'),
(7, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36', '127.0.0.1', 'test', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', '/account/', '2021-09-09 10:29:06.348862', '2021-09-09 12:49:09.582059'),
(8, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36', '127.0.0.1', 'mahan', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', '/account/', '2021-09-09 12:49:24.916862', '2021-09-09 13:24:10.176761'),
(9, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36', '127.0.0.1', 'mahan', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', '/account/', '2021-09-09 13:25:41.897413', '2021-09-09 14:27:59.086422'),
(10, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36', '127.0.0.1', 'mahan', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', '/account/', '2021-09-09 14:43:05.952615', NULL),
(11, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36', '127.0.0.1', 'mahan', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', '/account/', '2021-09-09 15:00:27.185610', NULL),
(12, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36', '127.0.0.1', 'mahan', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', '/account/', '2021-09-09 15:14:40.800853', NULL),
(13, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36', '127.0.0.1', 'test', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', '/account/', '2021-09-09 15:20:48.540491', '2021-09-10 05:36:59.592958'),
(14, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36', '127.0.0.1', 'test', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', '/account/', '2021-09-09 15:22:31.090897', '2021-09-10 05:36:59.592958'),
(15, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36', '127.0.0.1', 'mahan', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', '/account/', '2021-09-09 15:25:05.603097', NULL),
(16, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36', '127.0.0.1', 'test', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', '/account/', '2021-09-09 15:27:17.054963', '2021-09-10 05:36:59.592958'),
(17, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36', '127.0.0.1', 'test', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', '/account/', '2021-09-09 15:29:52.908885', '2021-09-10 05:36:59.592958'),
(18, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36', '127.0.0.1', 'test', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', '/account/', '2021-09-09 15:33:13.872057', '2021-09-10 05:36:59.592958'),
(19, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36', '127.0.0.1', 'adorf', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', '/admin/login/', '2021-09-10 03:47:20.668504', '2021-09-10 03:51:20.643336'),
(20, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36', '127.0.0.1', 'mahan', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', '/account/', '2021-09-10 03:52:32.069777', NULL),
(21, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36', '127.0.0.1', 'test', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', '/account/', '2021-09-10 05:35:36.414111', '2021-09-10 05:36:59.592958'),
(22, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36', '127.0.0.1', 'test', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', '/verify_otp/', '2021-09-10 11:31:32.233938', '2021-09-10 11:33:13.003980'),
(23, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36', '127.0.0.1', 'test', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', '/verify_otp/', '2021-09-10 11:34:02.861165', '2021-09-10 11:34:50.677677'),
(24, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36', '127.0.0.1', 'mahan', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', '/verify_otp/', '2021-09-10 11:36:12.413003', NULL),
(25, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36', '127.0.0.1', 'adorf', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', '/admin/login/', '2021-09-10 11:45:28.513838', '2021-09-10 11:46:08.095605'),
(26, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36', '127.0.0.1', 'test', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', '/verify_otp/', '2021-09-10 11:47:27.766141', NULL),
(27, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36', '127.0.0.1', 'adorf', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', '/admin/login/', '2021-09-10 11:49:32.993451', '2021-09-10 11:49:42.528222'),
(28, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36', '127.0.0.1', 'test', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', '/verify_otp/', '2021-09-10 11:50:27.213611', NULL),
(29, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36', '127.0.0.1', 'test', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9', '/verify_otp/', '2021-09-12 06:31:16.759327', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `dashboard_customer`
--

CREATE TABLE `dashboard_customer` (
  `id` bigint(20) NOT NULL,
  `name` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dashboard_customer`
--

INSERT INTO `dashboard_customer` (`id`, `name`, `email`, `user_id`) VALUES
(1, 'ADORF', 'adorf@gmail.com', 1),
(4, 'test', 'test@test.com', 7),
(7, 'mahan', 'mahansunuwar33@gmail.com', 10),
(8, 'sushant', 'susanwagle123@gmail.com', 11);

-- --------------------------------------------------------

--
-- Table structure for table `dashboard_order`
--

CREATE TABLE `dashboard_order` (
  `id` bigint(20) NOT NULL,
  `date_ordered` datetime(6) NOT NULL,
  `complete` tinyint(1) DEFAULT NULL,
  `transaction_id` varchar(200) DEFAULT NULL,
  `customer_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dashboard_order`
--

INSERT INTO `dashboard_order` (`id`, `date_ordered`, `complete`, `transaction_id`, `customer_id`) VALUES
(4, '2021-08-30 07:34:09.087597', 0, NULL, 1),
(5, '2021-09-02 14:48:26.802809', 1, '1630942751.894208', 4),
(6, '2021-09-04 14:35:21.120843', 1, '1631001984.673926', 7),
(7, '2021-09-06 05:32:35.079681', 0, NULL, 8),
(8, '2021-09-07 01:31:16.274242', 1, '1631002374.598183', 4),
(9, '2021-09-07 08:06:27.855043', 1, '1631191809.92716', 7),
(10, '2021-09-07 08:12:56.246246', 1, '1631189729.458958', 4),
(11, '2021-09-09 12:15:33.510269', 1, '1631190243.426394', 4),
(12, '2021-09-09 12:24:05.570077', 1, '1631274510.287939', 4),
(13, '2021-09-09 12:50:11.445861', 1, '1631246174.414149', 7),
(14, '2021-09-10 03:56:26.944184', 0, NULL, 7),
(15, '2021-09-10 11:48:42.107824', 0, NULL, 4);

-- --------------------------------------------------------

--
-- Table structure for table `dashboard_orderitem`
--

CREATE TABLE `dashboard_orderitem` (
  `id` bigint(20) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `date_added` datetime(6) NOT NULL,
  `order_id` bigint(20) DEFAULT NULL,
  `product_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dashboard_orderitem`
--

INSERT INTO `dashboard_orderitem` (`id`, `quantity`, `date_added`, `order_id`, `product_id`) VALUES
(7, 3, '2021-08-31 01:19:26.822160', 4, 3),
(9, 2, '2021-08-31 01:19:41.881807', 4, 2),
(13, 1, '2021-09-02 15:12:02.682962', 5, 2),
(14, 1, '2021-09-02 15:12:06.953281', 5, 3),
(15, 1, '2021-09-06 05:34:02.572587', 7, 3),
(16, 1, '2021-09-07 08:05:41.942245', 6, 2),
(17, 1, '2021-09-07 08:12:11.798202', 8, 3),
(18, 1, '2021-09-07 08:12:16.010253', 8, 2),
(19, 1, '2021-09-09 12:14:34.608736', 10, 2),
(20, 1, '2021-09-09 12:14:39.549105', 10, 4),
(21, 1, '2021-09-09 12:23:12.709994', 11, 3),
(22, 1, '2021-09-09 12:23:16.697691', 11, 2),
(23, 1, '2021-09-09 12:49:30.228635', 9, 3),
(24, 1, '2021-09-10 03:53:28.621154', 13, 2),
(25, 1, '2021-09-10 03:53:32.226507', 13, 3),
(26, 1, '2021-09-10 11:47:45.531906', 12, 2),
(27, 1, '2021-09-10 11:47:49.736803', 12, 1);

-- --------------------------------------------------------

--
-- Table structure for table `dashboard_payment`
--

CREATE TABLE `dashboard_payment` (
  `id` bigint(20) NOT NULL,
  `cname` varchar(200) DEFAULT NULL,
  `cardNum` varchar(200) DEFAULT NULL,
  `cvv` varchar(200) DEFAULT NULL,
  `exd` varchar(200) DEFAULT NULL,
  `date_added` datetime(6) NOT NULL,
  `customer_id` bigint(20) DEFAULT NULL,
  `order_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dashboard_payment`
--

INSERT INTO `dashboard_payment` (`id`, `cname`, `cardNum`, `cvv`, `exd`, `date_added`, `customer_id`, `order_id`) VALUES
(5, '0yFHuyWOtNA8O7sM9SDfog==', '8iUa15uA3UkGq_q7bo58Eg==', 'UjO8Dn0ZuCOIhS_EHNQUsw==', 'NFG5lr9wBUqIzVk9Vehbwg==', '2021-09-09 12:24:03.691184', 4, 11),
(7, 'GAHoWogg25ihHcFhGKgLwg==', 'FbsOaru1w1_6MTO4eEj4GQ==', 'LG1xondLY6CJEDIVb_7IeQ==', 'NFG5lr9wBUqIzVk9Vehbwg==', '2021-09-10 03:56:14.494640', 7, 13);

-- --------------------------------------------------------

--
-- Table structure for table `dashboard_product`
--

CREATE TABLE `dashboard_product` (
  `id` bigint(20) NOT NULL,
  `name` varchar(200) DEFAULT NULL,
  `price` double NOT NULL,
  `digital` tinyint(1) DEFAULT NULL,
  `image` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dashboard_product`
--

INSERT INTO `dashboard_product` (`id`, `name`, `price`, `digital`, `image`) VALUES
(1, 'Palazzo1', 300, 0, 'pi3_vcFlzWT.png'),
(2, 'Trouser1', 250, 0, 'pi2_SaHS65w.png'),
(3, 'Palazzo2', 400, 0, 'pi8_a48wKaO.png'),
(4, 'Trouser2', 500, 0, 'pi6_fx8c35S.png');

-- --------------------------------------------------------

--
-- Table structure for table `dashboard_shippingaddress`
--

CREATE TABLE `dashboard_shippingaddress` (
  `id` bigint(20) NOT NULL,
  `state` varchar(200) DEFAULT NULL,
  `city` varchar(200) DEFAULT NULL,
  `pickaddress` varchar(200) DEFAULT NULL,
  `date_added` datetime(6) NOT NULL,
  `customer_id` bigint(20) DEFAULT NULL,
  `order_id` bigint(20) DEFAULT NULL,
  `phoneNum` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dashboard_shippingaddress`
--

INSERT INTO `dashboard_shippingaddress` (`id`, `state`, `city`, `pickaddress`, `date_added`, `customer_id`, `order_id`, `phoneNum`) VALUES
(5, 'Bagmati', 'Bhaktapur', 'Chardobato', '2021-09-09 12:24:03.695186', 4, 11, '234215673'),
(7, 'Bagmati', 'Thimi', 'Chardobato', '2021-09-10 03:56:14.498565', 7, 13, '234567433');

-- --------------------------------------------------------

--
-- Table structure for table `django_admin_log`
--

CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) UNSIGNED NOT NULL CHECK (`action_flag` >= 0),
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `django_admin_log`
--

INSERT INTO `django_admin_log` (`id`, `action_time`, `object_id`, `object_repr`, `action_flag`, `change_message`, `content_type_id`, `user_id`) VALUES
(1, '2021-08-26 12:12:59.826651', '1', 'RedTrouser', 1, '[{\"added\": {}}]', 13, 1),
(2, '2021-08-26 12:13:16.450575', '2', 'RedSari', 1, '[{\"added\": {}}]', 13, 1),
(3, '2021-08-26 12:13:31.844845', '3', 'Kurtha', 1, '[{\"added\": {}}]', 13, 1),
(4, '2021-08-26 12:13:48.478078', '4', 'Black', 1, '[{\"added\": {}}]', 13, 1),
(5, '2021-08-26 12:14:02.122630', '5', 'Blue', 1, '[{\"added\": {}}]', 13, 1),
(6, '2021-08-26 12:14:15.588270', '6', 'Red', 1, '[{\"added\": {}}]', 13, 1),
(7, '2021-08-26 12:14:33.296535', '7', 'Jeans', 1, '[{\"added\": {}}]', 13, 1),
(8, '2021-08-26 12:14:49.118581', '8', 'Dotted', 1, '[{\"added\": {}}]', 13, 1),
(9, '2021-08-26 12:15:07.044428', '9', 'BJeans', 1, '[{\"added\": {}}]', 13, 1),
(10, '2021-08-27 03:30:19.271316', '1', 'Palazzo1', 1, '[{\"added\": {}}]', 9, 1),
(11, '2021-08-27 03:30:30.158092', '2', 'Trouser1', 1, '[{\"added\": {}}]', 9, 1),
(12, '2021-08-27 03:30:37.464897', '3', 'Palazzo2', 1, '[{\"added\": {}}]', 9, 1),
(13, '2021-08-27 03:30:52.378607', '4', 'Trouser2', 1, '[{\"added\": {}}]', 9, 1),
(14, '2021-08-27 03:35:53.926331', '1', 'Palazzo1', 2, '[{\"changed\": {\"fields\": [\"Image\"]}}]', 9, 1),
(15, '2021-08-27 03:36:15.074527', '2', 'Trouser1', 2, '[{\"changed\": {\"fields\": [\"Image\"]}}]', 9, 1),
(16, '2021-08-27 03:36:34.586270', '3', 'Palazzo2', 2, '[{\"changed\": {\"fields\": [\"Image\"]}}]', 9, 1),
(17, '2021-08-27 03:36:53.972183', '4', 'Trouser2', 2, '[{\"changed\": {\"fields\": [\"Image\"]}}]', 9, 1),
(18, '2021-08-27 03:55:58.863407', '1', 'ADORF', 1, '[{\"added\": {}}]', 7, 1),
(19, '2021-08-27 03:56:50.403318', '1', '1', 1, '[{\"added\": {}}]', 8, 1),
(20, '2021-08-27 04:00:02.084323', '2', 'OrderItem object (2)', 1, '[{\"added\": {}}]', 11, 1),
(21, '2021-08-27 04:00:09.430008', '2', 'OrderItem object (2)', 2, '[]', 11, 1),
(22, '2021-08-27 04:00:25.447242', '3', 'OrderItem object (3)', 1, '[{\"added\": {}}]', 11, 1),
(23, '2021-08-29 04:46:55.078338', '1', 'fsda', 3, '', 10, 1),
(24, '2021-08-29 07:55:45.379327', '6', 'OrderItem object (6)', 3, '', 11, 1),
(25, '2021-08-29 07:55:49.930406', '5', 'OrderItem object (5)', 3, '', 11, 1),
(26, '2021-08-29 07:55:53.729504', '3', 'OrderItem object (3)', 3, '', 11, 1),
(27, '2021-08-29 07:55:57.047912', '2', 'OrderItem object (2)', 3, '', 11, 1),
(28, '2021-08-29 07:56:03.682792', '2', '2', 3, '', 8, 1),
(29, '2021-08-29 07:56:08.271046', '1', '1', 3, '', 8, 1),
(30, '2021-08-30 06:43:59.899265', '3', '3', 3, '', 8, 1),
(31, '2021-09-02 13:23:43.944606', '2', 'hello', 3, '', 4, 1),
(32, '2021-09-02 13:26:21.076728', '3', 'hello', 3, '', 4, 1),
(33, '2021-09-02 14:47:30.953312', '1', 'customer', 1, '[{\"added\": {}}]', 3, 1),
(34, '2021-09-04 14:32:21.333735', '8', 'mahan', 3, '', 4, 1),
(35, '2021-09-04 14:32:27.096237', '9', 'mahan1', 3, '', 4, 1),
(36, '2021-09-07 01:27:13.861553', '1', 'Test', 1, '[{\"added\": {}}]', 14, 1),
(37, '2021-09-07 01:27:51.687936', '2', 'Bagmati', 1, '[{\"added\": {}}]', 10, 1),
(38, '2021-09-10 03:47:55.557897', '6', 'Hellq', 3, '', 14, 1),
(39, '2021-09-10 03:48:03.095952', '6', 'Kan', 3, '', 10, 1),
(40, '2021-09-10 11:49:41.103313', '8', 'Update', 3, '', 14, 1);

-- --------------------------------------------------------

--
-- Table structure for table `django_content_type`
--

CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(3, 'auth', 'group'),
(2, 'auth', 'permission'),
(4, 'auth', 'user'),
(16, 'axes', 'accessattempt'),
(17, 'axes', 'accesslog'),
(5, 'contenttypes', 'contenttype'),
(7, 'dashboard', 'customer'),
(8, 'dashboard', 'order'),
(11, 'dashboard', 'orderitem'),
(14, 'dashboard', 'payment'),
(9, 'dashboard', 'product'),
(12, 'dashboard', 'productmen'),
(13, 'dashboard', 'productwomen'),
(10, 'dashboard', 'shippingaddress'),
(15, 'defender', 'accessattempt'),
(6, 'sessions', 'session');

-- --------------------------------------------------------

--
-- Table structure for table `django_migrations`
--

CREATE TABLE `django_migrations` (
  `id` bigint(20) NOT NULL,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2021-08-23 07:41:01.276559'),
(2, 'auth', '0001_initial', '2021-08-23 07:41:22.053194'),
(3, 'admin', '0001_initial', '2021-08-23 07:41:23.171200'),
(4, 'admin', '0002_logentry_remove_auto_add', '2021-08-23 07:41:23.203210'),
(5, 'admin', '0003_logentry_add_action_flag_choices', '2021-08-23 07:41:23.228892'),
(6, 'contenttypes', '0002_remove_content_type_name', '2021-08-23 07:41:23.764696'),
(7, 'auth', '0002_alter_permission_name_max_length', '2021-08-23 07:41:24.045924'),
(8, 'auth', '0003_alter_user_email_max_length', '2021-08-23 07:41:24.109289'),
(9, 'auth', '0004_alter_user_username_opts', '2021-08-23 07:41:24.171148'),
(10, 'auth', '0005_alter_user_last_login_null', '2021-08-23 07:41:24.392769'),
(11, 'auth', '0006_require_contenttypes_0002', '2021-08-23 07:41:24.408407'),
(12, 'auth', '0007_alter_validators_add_error_messages', '2021-08-23 07:41:24.439641'),
(13, 'auth', '0008_alter_user_username_max_length', '2021-08-23 07:41:24.549013'),
(14, 'auth', '0009_alter_user_last_name_max_length', '2021-08-23 07:41:24.658398'),
(15, 'auth', '0010_alter_group_name_max_length', '2021-08-23 07:41:24.705259'),
(16, 'auth', '0011_update_proxy_permissions', '2021-08-23 07:41:24.752132'),
(17, 'auth', '0012_alter_user_first_name_max_length', '2021-08-23 07:41:24.845896'),
(18, 'dashboard', '0001_initial', '2021-08-23 07:41:26.979663'),
(19, 'sessions', '0001_initial', '2021-08-23 07:41:27.351497'),
(20, 'dashboard', '0002_auto_20210823_1851', '2021-08-23 13:06:53.579927'),
(21, 'dashboard', '0003_product_image', '2021-08-23 13:30:09.203849'),
(22, 'dashboard', '0004_auto_20210826_1753', '2021-08-26 12:09:21.490755'),
(23, 'dashboard', '0005_auto_20210827_0908', '2021-08-27 03:23:48.199287'),
(24, 'dashboard', '0006_auto_20210828_1105', '2021-08-28 05:20:28.786770'),
(25, 'dashboard', '0007_payment', '2021-09-06 15:23:46.962290'),
(26, 'dashboard', '0008_auto_20210907_1347', '2021-09-07 08:02:23.857341'),
(27, 'defender', '0001_initial', '2021-09-09 04:10:16.675961'),
(28, 'defender', '0002_alter_accessattempt_id', '2021-09-09 04:36:57.231062'),
(29, 'axes', '0001_initial', '2021-09-09 07:55:11.911898'),
(30, 'axes', '0002_auto_20151217_2044', '2021-09-09 07:55:12.648927'),
(31, 'axes', '0003_auto_20160322_0929', '2021-09-09 07:55:12.700931'),
(32, 'axes', '0004_auto_20181024_1538', '2021-09-09 07:55:12.739916'),
(33, 'axes', '0005_remove_accessattempt_trusted', '2021-09-09 07:55:12.768497'),
(34, 'axes', '0006_remove_accesslog_trusted', '2021-09-09 07:55:12.812002'),
(35, 'dashboard', '0009_auto_20210909_1753', '2021-09-09 12:08:38.542819'),
(36, 'dashboard', '0010_auto_20210909_1757', '2021-09-09 12:13:11.188000'),
(37, 'dashboard', '0011_auto_20210909_1803', '2021-09-09 12:18:43.510295'),
(38, 'dashboard', '0012_auto_20210909_1805', '2021-09-09 12:20:49.677722'),
(39, 'dashboard', '0013_auto_20210909_1810', '2021-09-09 12:25:13.558375'),
(40, 'dashboard', '0014_orderitem_customer', '2021-09-09 13:33:28.585932'),
(41, 'dashboard', '0015_alter_orderitem_customer', '2021-09-09 13:37:57.881822'),
(42, 'dashboard', '0016_remove_orderitem_customer', '2021-09-09 13:37:58.035763');

-- --------------------------------------------------------

--
-- Table structure for table `django_session`
--

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('0ks4ol7qoznyr7ecmc7d5qs7w35excwf', '.eJxVjjFuxCAQRe9CHSEPYGy2ilKkyxnQAOOYbAwrD1aK1d49WNpmu9H773_NXRxMe8GNxEU04ibexA2Z_-qeOvk84vUdlDYdeybmXIvPJTff8tZt3G5eXMBqUJOxCqRxxlrbZTza6s9tn8-hSbywgPFK5QzSD5bvKmMtbc9Bnop8piy_aqLfj6f7MrAir70NIyBE52zQox3GsISkFj0jkknzkmL_LPXDuGmAmRwoogEMkUYzTiks4vEPBTZTjg:1mOf35:WMLYKqdkkNZMFuzlOo2Wn93y8tNkRqeRmiLmLAkDGDM', '2021-09-24 11:50:27.280309'),
('47avxyl8ostzbm5tp3tchwptl3du1z9m', '.eJxVjEsOwjAMBe-SNYrcJo1tluw5Q-XEKS2gROpnhbg7VOoCtm9m3sv0sq1jvy157ic1Z4Pm9LtFSY9cdqB3KbdqUy3rPEW7K_agi71Wzc_L4f4djLKM3zoTCLYDMRKhCjodOKI2DE4RcisuRR-589LIANRBCh59SEzMDIHM-wPgzjc_:1mM2Zy:nKtDfjd7sJQmAvETMEq7DsODJGGwb7oWM8UrKxsmOH4', '2021-09-17 06:21:34.754690'),
('5y6ig8wlgkgpqo1yki1xz4rmhqha0yvc', '.eJxVjEsOwjAMBe-SNYrcJo1tluw5Q-XEKS2gROpnhbg7VOoCtm9m3sv0sq1jvy157ic1Z4Pm9LtFSY9cdqB3KbdqUy3rPEW7K_agi71Wzc_L4f4djLKM3zoTCLYDMRKhCjodOKI2DE4RcisuRR-589LIANRBCh59SEzMDIHM-wPgzjc_:1mLoLb:cIHt1rJHDNOlrdyE0KfNlu1R_eVw27lwBI6GM3-ogOE', '2021-09-16 15:09:47.315294'),
('6usrgmlnavvweqe9bdiw6qjtw4htlwbk', '.eJxVjDsOwyAQRO9CHSE-XjAp0_sMaFkgOIlAMnYV5e6xJRdJM8W8N_NmHre1-K2nxc-RXZlkl98uID1TPUB8YL03Tq2uyxz4ofCTdj61mF630_07KNjLvtYxSmsySDQmGySrRSYniAi0AhiUEiELPUo3ZkQB1oGNyro9IA-C2OcL18o3Qw:1mINze:DjhDzmrgK2fLjjE_QcInVEqwHQGrUhlKG-dh9MYleOg', '2021-09-07 04:24:58.560180'),
('73l0h8jjcyzihp7i4aqn4xz9jq6i9ek8', '.eJxVjDsOwjAQBe_iGln-fyjpOYO19q5xADlSnFSIu0OkFNC-mXkvlmBbW9oGLWlCdmZSsNPvmKE8qO8E79BvMy9zX5cp813hBx38OiM9L4f7d9BgtG9ds_EUQxRQDJVK1imyURtQWdTgpFfFR09WC68DWlABrAtS6UqAJJG9PwqgOBU:1mMXVj:QRFNpwAGms4go1lJQU2sfpU9CwwGM2x44OzmvFo82So', '2021-09-18 15:23:15.809900'),
('7ifwbd08vhu6opip1f55szzvurgz5n0e', '.eJxVjrkOwyAQRP-FOkJcWrwu0-cbEMc6JgdEBldR_j225MbtvDej-TLXqLVci8sld9fzm1r3749jowQtJSKg5GLQAuSFOb_22a2NFpcTG5kU7BQGH59UdpIevtwrj7X0JQe-K_ygjd9qotf1cE8Ds2_z1g4IibRVIMB6SJPxhqKyVimiIFJE1NJOaTCEKm7PMKIxJCRECpiEYr8_BUxGLg:1mOLYR:nw6MxOYpnpn730RAZ3iIJ92gCFS4NYSLk45s9WQtPGk', '2021-09-23 15:01:31.530274'),
('8aeukizatv5jc4dcne3mhctr3m96cxlo', '.eJxVjMsOwiAUBf-FtSGXd-nSvd9AoFwsasEUujL-uzbpptszM-dDXMPWci0ul9xdzwu27pe3IyPTgnFgjBsqNVht1IU4v_XZbQ1XlyMZCQNyGoOfnlh2Eh--3CudaulrDnRX6EEbvdWIr-vhng5m3-Z_LSWg8GngSSsVoorWGqOkVtpA5EnEBAoE14mHCcEiFxPTMvE0BEwQLPn-ABluRis:1mOLvc:Qvhd9Nd7N8aQkotK7rd4og660S1J4whteiRU1snaeLI', '2021-09-23 15:25:28.043460'),
('a7w7r7pmlerct9babrenbblw0zltvloe', '.eJxVjEEOgyAQRe_CuiEMKKLL7nsGMiNDpa3YCK6a3r01ceP2v_f-R_jCpaQl-5RT9TXNXCrOby8GsAa0grZzUjfgeqUvwuNWJ78VXn0KYhCdOG2E45PzDsID832R45Lrmkjuijxokbcl8Ot6uKeDCcv0r3VAbSByhBAsuQix7dGAHQEtoiVwrcNGGwblgHTT2TFEJkKK5BSy-P4AG3NHVA:1mOM3q:x0uWNYIdTmcCgt9cp_97p14RPbwgU8HGJd-7duEjtWY', '2021-09-23 15:33:58.129558'),
('aq83ktkwvzq475rbsjxzd5td9ama429j', 'e30:1mOdWT:bnLE_r2Ek4uutuitPrbBzXRwIYWXC-mXgwjLgzIj1fA', '2021-09-24 10:12:41.104596'),
('chv7i3edjtcsmzx9s9begyifumnavkqv', '.eJxVjDsOwyAQRO9CHSHz8Rpcps8Z0ALrmHwgMriKcvfYkouknJk3780crm12a6XFpchGJjp2-i09hjvlfYk3zNfCQ8ltSZ7vCD_Wyi8l0uN8sH-CGeu8vbEffFCWRIxe9ioaswWSkiZCFFNngKwSFNAAyEDBCqvBa5AdmWHqwy6tVGsq2aWcmmvpSbXh8-XYKEAJqUELzcFoZTv1-QLJE0b0:1mOXi2:kNCUJCO316VYsuhnbWiW5gi8V3nJNvbUHCD16IlrTEc', '2021-09-24 04:00:14.730396'),
('esjhvk4tzdjfo60ezhnr715umj0s4nsm', 'eyJvdHAiOiIzNjQwIiwiX3Nlc3Npb25faW5pdF90aW1lc3RhbXBfIjoxNjMxMjY5MjQ3LjIzMDAwM30:1mOdeU:ylKY57b2Fqck3GhNY4IhXf5jsnT79x92eo2wD7qi7Gc', '2021-09-24 10:20:58.619058'),
('gozfsvg79hluh9quprc5gi3dthrlfecz', 'eyJfc2Vzc2lvbl9pbml0X3RpbWVzdGFtcF8iOjE2MzEyNzEwODMuMDU3MDk4OSwidXNlcm5hbWUiOiJ0ZXN0In0:1mOe7v:cvSxMFfhA9YX0fm4n9c9-Kvuwjf5XsfOAXxCOwzQgzs', '2021-09-24 10:51:23.060103'),
('hgali17wzpsnejuysazbn22rc8q1vybz', 'eyJfc2Vzc2lvbl9pbml0X3RpbWVzdGFtcF8iOjE2MzEyNzAwNTYuMjA2Njg2M30:1mOdsD:LgIFoha8SG2wOn4mX0Bv_adRxQBVVEcxSDz6MfzGQvM', '2021-09-24 10:35:09.366949'),
('jk9dxnr13xowlv2l87sbazs2r12g9rha', 'eyJfc2Vzc2lvbl9pbml0X3RpbWVzdGFtcF8iOjE2MzEyNjk5NDguNjk4MTc1N30:1mOdq3:oScDsLKrp9N5tV48l-SJqemgvXLibF6gAOa0cH2qyGI', '2021-09-24 10:32:55.838900'),
('lcny5dn73yk0flfih5owy6eda6k6qbuw', 'eyJfc2Vzc2lvbl9pbml0X3RpbWVzdGFtcF8iOjE2MzEyNzMyNzYuMDgzNzY4LCJ1c2VybmFtZSI6InRlc3QifQ:1mOehr:3XjeFQW1HUaoRYjlzG9sYLL2VffSrE6n2KOiSShLC6w', '2021-09-24 11:28:31.512555'),
('mpljfg0b8nz4v6pucz7nd1g2shxndp8r', '.eJxVjDsOwyAQBe9CHSHWGAwu0-cMaA1LTD4QGVxFuXtsyUXSvpk3b-ZwbbNbKy0uBTYyEOz0O07o75R3Em6Yr4X7ktuSJr4r_KCVX0qgx_lw_wIz1nl7o7BojECLaAaheykhRBgIaJh8nHodOgqI0XolbR9j53VEisEjKCuN2qOVak0lu5RTcy09qTZ8vhwbQUsAa6VSfHO1VZ8vkyNHWg:1mOLTV:kGupIsf6BSLE_aljOHSn8cYMTaf4Uc3ZpU9QIr42QwI', '2021-09-23 14:56:25.111674'),
('nc0kddfmem90jzy451sbht48rmc1jlgc', '.eJxVjEEOwiAQRe_C2hAGho7t0r1nIBQGi1pqCl0Z764m3XT733v_LVzlWvNSXC65uZZnrs3PLycG6AxoBVqDBFCojD0J57c2ua3y6nIUgyBx2EYfHlz-IN59uS0yLKWteZR_Re60yusS-XnZ3cPB5Ov0qzlgT7an0WqkREn3Jnom8Mkm6iNAUEQ-YgcmkcKzxhFRaROswo6BxecL3nhFUw:1mOLy1:ZMKlt9d_8KCTt5Q5ey3c9pcxKikndTCzCUn6npH6-O0', '2021-09-23 15:27:57.545757'),
('o78rgp3s79oynr59pgutqul9vxd1clyz', '.eJxVjDsOgzAQBe_iOrLWYFgvZfqcwVp_CE6CibCpotw9QaKhfTPzPsKWWEpask05VVvTHEvl-W3FoPpWNQAGlWwUkCZ9EZa3OtmtxNWmIAaB4rQ59s-YdxAenO-L9Euua3JyV-RBi7wtIb6uh3s6mLhM_zoaYGxGQ2gMBsY2jOQwKII2IMSGW--0o06z4hFMB77XqHtPhoigN-L7A_gjRYk:1mOLrT:gv-jXEnKDCSsUtSgo2vZh2lB5cCa66xoTAuOAntSzlE', '2021-09-23 15:21:11.828868'),
('p02g85mj6k9ci5uk2nav6rxgjx2195bj', '.eJxVjDsOwyAQRO9CHSE-XjAp0_sMaFkgOIlAMnYV5e6xJRdJM8W8N_NmHre1-K2nxc-RXZlkl98uID1TPUB8YL03Tq2uyxz4ofCTdj61mF630_07KNjLvtYxSmsySDQmGySrRSYniAi0AhiUEiELPUo3ZkQB1oGNyro9IA-C2OcL18o3Qw:1mL0oI:g8O8eNos6h5Q2O772SjPT3AT7XUU6N_aFXEvuDcU2BY', '2021-09-14 10:16:06.922627'),
('p321ulabz8qgxn9i4hkn06ja5y5vdc4f', '.eJxVjEsOwjAMBe-SNYrcJo1tluw5Q-XEKS2gROpnhbg7VOoCtm9m3sv0sq1jvy157ic1Z4Pm9LtFSY9cdqB3KbdqUy3rPEW7K_agi71Wzc_L4f4djLKM3zoTCLYDMRKhCjodOKI2DE4RcisuRR-589LIANRBCh59SEzMDIHM-wPgzjc_:1mNPxE:ShZE07aYAmn9LQj11HwUfzCJhHkivrDrtMI4d8VD9oQ', '2021-09-21 01:31:16.186656'),
('qmu6pkntspxdvhu27llrqyyuitjdqkcd', '.eJxVjDsOwyAQBe9CHaGFBfwp0-cMaO3FMUkMkcFVlLsnlty4fTPzPsKXUErMyccUq69xCaXS8vaiVw6VBjC2kdA4i8ZehKetzn4rYfWRRS8UiNM40PgMaSf8oHTPcsyprnGQuyIPWuQtc3hdD_d0MFOZ_7VtuGWnGBRpNF2LYKepA23NYIBg0hoJ2VE7jjwghg4tsdOWurYxmlh8fw8oRdw:1mOLlc:uuWXt5yKiohhg3_7BMq8FgOROv_PU4IkD_Vv7eAQf_Y', '2021-09-23 15:15:08.865460'),
('r8o5a8q2gq1812x6z64vs88vwbimok0j', 'eyJfc2Vzc2lvbl9pbml0X3RpbWVzdGFtcF8iOjE2MzEyNzA2MjIuMDM2NjAzNSwidXNlcm5hbWUiOiJ0ZXN0In0:1mOe11:dT6XsfsjBxd9YJ8D3s1gktvUp_HMYS2cv2izDKM2Bpg', '2021-09-24 10:44:15.526453'),
('v3arynwv5djhybmfpq042uwlje1z7hkj', '.eJxVjEsOwjAMBe-SNYrcJo1tluw5Q-XEKS2gROpnhbg7VOoCtm9m3sv0sq1jvy157ic1Z4Pm9LtFSY9cdqB3KbdqUy3rPEW7K_agi71Wzc_L4f4djLKM3zoTCLYDMRKhCjodOKI2DE4RcisuRR-589LIANRBCh59SEzMDIHM-wPgzjc_:1mNGZ6:Fg4Z-w-mDMENEU6aOSIDiIGEat6UgO_MufryWbsdKgA', '2021-09-20 15:29:44.886536'),
('v9btps4a4uop3dmr1ztbyvzlvdci7c6j', 'eyJfc2Vzc2lvbl9pbml0X3RpbWVzdGFtcF8iOjE2MzEyNzEyNDkuNjM5ODI2LCJ1c2VybmFtZSI6InRlc3QifQ:1mOeBB:l0WnTiS2uS4V4WvvH-CxLIqr6OLIb0SCvXzqfr5g9zo', '2021-09-24 10:54:45.012608'),
('ve4tudj8it9hlwsih0xbjzvfs8gxiepg', '.eJxVjDsOwyAQRO9CHSE-XjAp0_sMaFkgOIlAMnYV5e6xJRdJM8W8N_NmHre1-K2nxc-RXZlkl98uID1TPUB8YL03Tq2uyxz4ofCTdj61mF630_07KNjLvtYxSmsySDQmGySrRSYniAi0AhiUEiELPUo3ZkQB1oGNyro9IA-C2OcL18o3Qw:1mJThT:f9p-JJCV2PBy9OOyMdNPyr1HosSlVGaXX64F1JYuLbo', '2021-09-10 04:42:43.570197'),
('w50woxow5cqf30g0jlzxopmbqmho5zwe', '.eJxVjMEOwiAQBf-FsyHQwlJ69O43kAW2FrVgCj0Z_12b9NLrm5n3Ya5Sralkl3JqrqWFasPl7dgooZedkL2R3IAGMOrCHG5tdlul1aXIRmbYafMYnpR3EB-Y74WHktuaPN8VftDKbyXS63q4p4MZ6_yvNQQ0BMoidTZG76cJyGpCChrRakA7kVFiGGQkK2MQ0AtltOiC9b2W7PsDNYpGyw:1mOM0G:6F4IYG04dEiij1J9h868EGYzs-IVKa2h3_ueUQo949k', '2021-09-23 15:30:16.363968'),
('w8kvlh5cyo0eq819f6ie4bzfxvn5dqux', 'eyJfc2Vzc2lvbl9pbml0X3RpbWVzdGFtcF8iOjE2MzEyNzA5MDcuOTg1OTQ1LCJ1c2VybmFtZSI6InRlc3QifQ:1mOe5q:UgeoD2uM_vnbXsk6XGmKuLFCK7b-tvKacl7y7SyivLU', '2021-09-24 10:49:14.445898'),
('wu67u7vyhdoanwd2ln5n6vjpoglj0z65', '.eJxVjjFuxCAQRe9CHSEPYIy3ilKkyxnQAOOYbAwrD1aK1d49WNpmu9H773_NXRxMe8GNxEU04ibexA2Z_-qeOvk84vUdlDYdeybmXIvPJTff8tZt3G5eXMBqMMopC9IaNbnu4tFWf077fO5M4oUFjFcqZ5B-sHxXGWtpew7yVOQzZflVE_1-PN2XgRV57W0YASHOsw16tMMYlpDUoh0imeSWFPtjqR9mngZwNIMiGsAQaTTjlMIiHv_E7VNX:1mPJ1I:D53vF_FbaH_nblVBO_eI1dkoq8jLHFrKVHMEIWAvKiQ', '2021-09-26 06:31:16.844606'),
('xj6vrmhnhhugxsi2tmghxhwlxoylrcnx', 'e30:1mOdZX:LdugbLVYrhqlj2P-MC7jBQLzhQ22GiqDaIODE-05f84', '2021-09-24 10:15:51.927611'),
('ys3nw119irhixitr037dksoenql60q9u', 'eyJfc2Vzc2lvbl9pbml0X3RpbWVzdGFtcF8iOjE2MzEyNzAwMTYuMzY3MTg0OX0:1mOdqi:zTbXIX3yPPLa5Qdh3ph5sKs3KaiRMOUaOFIMZa5W4KM', '2021-09-24 10:33:36.373185'),
('zctiea9guolyya2yun2016rjjfca218r', '.eJxVjDsOwyAQBe9CHSFgvRi7TJ8zoOUXkw-ODK6i3D225MbtzLz3ZbbGWvNcbC652ZbfsTZ6fywbpQaphBiU5INEVAouzNLaJrvWuNgc2Mh6dmKO_DOWXYQHlfvM_Vzakh3fE37Yym9ziK_r0Z4OJqrTtk6COh20Md4pA9ip4AwBeikTOnQSehU2kcBoP6QACZXrCTeghQAh2O8P7ylFfg:1mOLt9:DlsiBS6NXycthAZ8N0X6JyuPknnsTezDCnxZZB3PkFc', '2021-09-23 15:22:55.505695');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auth_group`
--
ALTER TABLE `auth_group`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  ADD KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`);

--
-- Indexes for table `auth_user`
--
ALTER TABLE `auth_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  ADD KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`);

--
-- Indexes for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  ADD KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `axes_accessattempt`
--
ALTER TABLE `axes_accessattempt`
  ADD PRIMARY KEY (`id`),
  ADD KEY `axes_accessattempt_ip_address_10922d9c` (`ip_address`),
  ADD KEY `axes_accessattempt_user_agent_ad89678b` (`user_agent`),
  ADD KEY `axes_accessattempt_username_3f2d4ca0` (`username`);

--
-- Indexes for table `axes_accesslog`
--
ALTER TABLE `axes_accesslog`
  ADD PRIMARY KEY (`id`),
  ADD KEY `axes_accesslog_ip_address_86b417e5` (`ip_address`),
  ADD KEY `axes_accesslog_user_agent_0e659004` (`user_agent`),
  ADD KEY `axes_accesslog_username_df93064b` (`username`);

--
-- Indexes for table `dashboard_customer`
--
ALTER TABLE `dashboard_customer`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `dashboard_order`
--
ALTER TABLE `dashboard_order`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dashboard_order_customer_id_36598346_fk_dashboard_customer_id` (`customer_id`);

--
-- Indexes for table `dashboard_orderitem`
--
ALTER TABLE `dashboard_orderitem`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dashboard_orderitem_order_id_2831b941_fk_dashboard_order_id` (`order_id`),
  ADD KEY `dashboard_orderitem_product_id_6b134f90_fk_dashboard_product_id` (`product_id`);

--
-- Indexes for table `dashboard_payment`
--
ALTER TABLE `dashboard_payment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dashboard_payment_customer_id_2c998051_fk_dashboard_customer_id` (`customer_id`),
  ADD KEY `dashboard_payment_order_id_841e7964_fk_dashboard_order_id` (`order_id`);

--
-- Indexes for table `dashboard_product`
--
ALTER TABLE `dashboard_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dashboard_shippingaddress`
--
ALTER TABLE `dashboard_shippingaddress`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dashboard_shippingad_customer_id_d967703c_fk_dashboard` (`customer_id`),
  ADD KEY `dashboard_shippingad_order_id_0b216d09_fk_dashboard` (`order_id`);

--
-- Indexes for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  ADD KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`);

--
-- Indexes for table `django_content_type`
--
ALTER TABLE `django_content_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`);

--
-- Indexes for table `django_migrations`
--
ALTER TABLE `django_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `django_session`
--
ALTER TABLE `django_session`
  ADD PRIMARY KEY (`session_key`),
  ADD KEY `django_session_expire_date_a5c62663` (`expire_date`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auth_group`
--
ALTER TABLE `auth_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_permission`
--
ALTER TABLE `auth_permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT for table `auth_user`
--
ALTER TABLE `auth_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `axes_accessattempt`
--
ALTER TABLE `axes_accessattempt`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `axes_accesslog`
--
ALTER TABLE `axes_accesslog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `dashboard_customer`
--
ALTER TABLE `dashboard_customer`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `dashboard_order`
--
ALTER TABLE `dashboard_order`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `dashboard_orderitem`
--
ALTER TABLE `dashboard_orderitem`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `dashboard_payment`
--
ALTER TABLE `dashboard_payment`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `dashboard_product`
--
ALTER TABLE `dashboard_product`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `dashboard_shippingaddress`
--
ALTER TABLE `dashboard_shippingaddress`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `django_content_type`
--
ALTER TABLE `django_content_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `django_migrations`
--
ALTER TABLE `django_migrations`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`);

--
-- Constraints for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- Constraints for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `dashboard_customer`
--
ALTER TABLE `dashboard_customer`
  ADD CONSTRAINT `dashboard_customer_user_id_6f1d2062_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `dashboard_order`
--
ALTER TABLE `dashboard_order`
  ADD CONSTRAINT `dashboard_order_customer_id_36598346_fk_dashboard_customer_id` FOREIGN KEY (`customer_id`) REFERENCES `dashboard_customer` (`id`);

--
-- Constraints for table `dashboard_orderitem`
--
ALTER TABLE `dashboard_orderitem`
  ADD CONSTRAINT `dashboard_orderitem_order_id_2831b941_fk_dashboard_order_id` FOREIGN KEY (`order_id`) REFERENCES `dashboard_order` (`id`),
  ADD CONSTRAINT `dashboard_orderitem_product_id_6b134f90_fk_dashboard_product_id` FOREIGN KEY (`product_id`) REFERENCES `dashboard_product` (`id`);

--
-- Constraints for table `dashboard_payment`
--
ALTER TABLE `dashboard_payment`
  ADD CONSTRAINT `dashboard_payment_customer_id_2c998051_fk_dashboard_customer_id` FOREIGN KEY (`customer_id`) REFERENCES `dashboard_customer` (`id`),
  ADD CONSTRAINT `dashboard_payment_order_id_841e7964_fk_dashboard_order_id` FOREIGN KEY (`order_id`) REFERENCES `dashboard_order` (`id`);

--
-- Constraints for table `dashboard_shippingaddress`
--
ALTER TABLE `dashboard_shippingaddress`
  ADD CONSTRAINT `dashboard_shippingad_customer_id_d967703c_fk_dashboard` FOREIGN KEY (`customer_id`) REFERENCES `dashboard_customer` (`id`),
  ADD CONSTRAINT `dashboard_shippingad_order_id_0b216d09_fk_dashboard` FOREIGN KEY (`order_id`) REFERENCES `dashboard_order` (`id`);

--
-- Constraints for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  ADD CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
